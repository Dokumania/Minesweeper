﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;

namespace Minestryger
{
    public partial class Form1 : Form
    {
        public int mineCount = 10;
        int revealedTiles = 0;
        int tiles;
        public int rows = 8;
        public int columns = 8;
        bool gameDone = false;




        public Form1()
        {
            InitializeComponent();

            // Definerer spillebrættet

            BoardsizeForm boardsizeForm = new BoardsizeForm(this);
            boardsizeForm.ShowDialog();

            MinimumSize = new Size(Width, Height);

            MaximumSize = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;

            // Scaler med alle sider af vinduet
            
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = columns;

            tableLayoutPanel1.RowCount = rows;

            // Definerer antal felter som række gange kolonne

            tiles = rows * columns;
            
            // Laver en knap for hver gyldigt felt. 
            // b.MouseUp udfører klik ved eventet. 

            for (int i = 0; i < tiles; i++)
            {
                MineButton b = new MineButton();
                b.Width = 32;
                b.Height = 32;
                tableLayoutPanel1.Controls.Add(b);
                b.MouseUp += b_Click;
            }

            // PopulateMines kaldes for at tildele miner til spillebrættet. 

            PopulateMines();

            // Tæller antal af miner om et felt

            for (int i = 0; i < columns; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    CountAdjacent(i, j);
                }

            }

            //Felter autoscaleres betinget af antal af kolonner og rækker
            foreach (ColumnStyle style in tableLayoutPanel1.ColumnStyles)
            {
                style.SizeType = SizeType.AutoSize;
               
            }

            foreach (RowStyle style in tableLayoutPanel1.RowStyles)
            {
                style.SizeType = SizeType.AutoSize;
                
            }
        }


        //Definerer CountAdjacent funktionen
        void CountAdjacent(int x, int y)
        {
            
            //Koordinater ud fra knappen
            MineButton b = (MineButton)tableLayoutPanel1.GetControlFromPosition(x, y);


            //Der laves et for løkke der tæller antal af miner af de omkringliggende felter. 
            //For loopet tæller fra -1 til +1 på hver akse
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                    {
                        continue;
                    }

                    //Hvis x+offset og y+offset plus koordinattet til mines position giver et negativt tal eller højere end antal af rækker og kolonner ignoeres disse. 

                    if (x + i < 0 || x + i > columns - 1 || y + j < 0 || y + j > rows - 1)
                    {
                        continue;
                    }

                    //Koordinater til det felt med en mine på
                    MineButton m = (MineButton)tableLayoutPanel1.GetControlFromPosition(x + i, y + j);


                    //Hvis feltet indeholder en mine gør så b.adjacentMines én større. 
                    if (m.isMine)
                    {
                        b.adjacentMines++;
                    }
                }
            }

        }

        //Klikfunktion når der klikkes på et felt
        void b_Click(object sender, MouseEventArgs e)
        {
            MineButton b = (MineButton)sender;


            //Hvis der venstreklikkes på et felt med en mine derpå, så er det GAME OVER.

            if (e.Button == MouseButtons.Left)
            {
                if (b.isMine == true)
                {
                    MessageBox.Show("GAME OVER");
                    this.Close();
                    Application.Exit();
                    gameDone = true;
                    return;
                }

                //Hvis et felt ikke indeholder mine, da gør revealedTiles én større. 
                //Hvis antal af felter minus afsløret felter er lig med antal af miner, så har du vundet
                else
                {
                    b.isRevealed = true;
                    revealedTiles++;
                    if (tiles - revealedTiles == mineCount)
                    {
                        MessageBox.Show("YOU WIN!");
                        this.Close();
                        Application.Exit();
                        gameDone = true;
                        return;
                    }
                    //Hvis feltet bliver repræsenteret af et 0, så køres if statementet og revealer de omkringliggende felter der indeholder et 0
                    //Såfremt det ikke er et 0 så afsløres feltet og funktionen termineres
                    if (b.adjacentMines == 0)
                    {
                        TableLayoutPanelCellPosition position = tableLayoutPanel1.GetPositionFromControl(b);
                        int x = position.Column;
                        int y = position.Row;
                        for (int i = -1; i <= 1; i++)
                        {
                            for (int j = -1; j <= 1; j++)
                            {
                                if (gameDone)
                                {
                                    return;
                                }
                                if (i == 0 && j == 0)
                                {
                                    continue;
                                }


                                if (x + i < 0 || x + i > tableLayoutPanel1.ColumnCount - 1 || y + j < 0 || y + j > tableLayoutPanel1.RowCount - 1)
                                {
                                    continue;
                                }
                                MineButton m = (MineButton)tableLayoutPanel1.GetControlFromPosition(x + i, y + j);

                                if (m.isRevealed)
                                {
                                    continue;
                                }

                                b_Click(m, e);
                                

                            }
                        }
                    }


                }
            }

            //Hvis der højreklikkes på et felt så sættes et flag

            if (e.Button == MouseButtons.Right)
            {
                b.isFlagged = !b.isFlagged;

            }

            b.Invalidate();



        }

        //Der genereres tilfældig miner, som en x og y koordinat i form af række og kolonne
        //Hvis feltet allerede indeholder en mine, så trækkes én fra i og fortsætter med tildele miner
        public void PopulateMines()
        {
            Random rng = new Random();
            for (int i = 0; i < mineCount; i++)
            {
                int x = rng.Next(0, columns);
                int y = rng.Next(0, rows);

                MineButton b = (MineButton)tableLayoutPanel1.GetControlFromPosition(x, y);

                if (b.isMine)
                {
                    i--;
                    continue;
                }

                b.isMine = true;
            }
        }
    }


}
