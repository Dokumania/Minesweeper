﻿
namespace Minestryger
{
    partial class BoardsizeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numRow = new System.Windows.Forms.NumericUpDown();
            this.numColumn = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.numMine = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numRow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColumn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMine)).BeginInit();
            this.SuspendLayout();
            // 
            // numRow
            // 
            this.numRow.Location = new System.Drawing.Point(92, 65);
            this.numRow.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.numRow.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numRow.Name = "numRow";
            this.numRow.Size = new System.Drawing.Size(348, 22);
            this.numRow.TabIndex = 1;
            this.numRow.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // numColumn
            // 
            this.numColumn.Location = new System.Drawing.Point(92, 33);
            this.numColumn.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.numColumn.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numColumn.Name = "numColumn";
            this.numColumn.Size = new System.Drawing.Size(348, 22);
            this.numColumn.TabIndex = 0;
            this.numColumn.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Række";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Kolonne";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(521, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Miner";
            // 
            // numMine
            // 
            this.numMine.Location = new System.Drawing.Point(92, 114);
            this.numMine.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numMine.Name = "numMine";
            this.numMine.Size = new System.Drawing.Size(348, 22);
            this.numMine.TabIndex = 3;
            this.numMine.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // BoardsizeForm
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 156);
            this.Controls.Add(this.numMine);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numColumn);
            this.Controls.Add(this.numRow);
            this.Name = "BoardsizeForm";
            this.Text = "BoardsizeForm";
            ((System.ComponentModel.ISupportInitialize)(this.numRow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numColumn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMine)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numRow;
        private System.Windows.Forms.NumericUpDown numColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numMine;
    }
}