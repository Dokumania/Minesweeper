﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minestryger
{
    public partial class BoardsizeForm : Form
    {
        Form1 parent;


        public BoardsizeForm(Form1 parent)
        {
            InitializeComponent();
            this.parent = parent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            parent.rows = (int)numRow.Value;
            parent.columns = (int)numColumn.Value;

            parent.mineCount = (int)numMine.Value;

            //Hvis antal miner er større end antallet af brætspillets felter så returneres en fejlbedsked

            if (numMine.Value >= numRow.Value * numColumn.Value)
            {
                MessageBox.Show("Antal indtastet miner er større end eller lig med brætspillets størrelse", "Fejl", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.Close();



        }


    }
}
