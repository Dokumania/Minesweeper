﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minestryger
{
    class MineButton : Button
    {
        public bool isMine = false;
        public bool isFlagged = false;
        public bool isRevealed = false;
        public int adjacentMines;


        public override string Text
        {
            get
            {
              
                //Hvis felt er revealed så skriv antal af miner derpå
                if (isRevealed == true)
                {
                    return adjacentMines.ToString();
                }

                //Hvis der er sat et flag så returneres et "f" på feltet

                if (isFlagged == true)
                {
                    return "f";
                }
                return "";

            }
        }


    }
}
