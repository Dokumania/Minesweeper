﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;

namespace Minestryger
{
    public partial class Form1 : Form
    {
        public int mineCount = 10;
        int revealedTiles = 0;
        int tiles;
        public int rows = 8;
        public int columns = 8;





        public Form1()
        {
            InitializeComponent();

            BoardsizeForm boardsizeForm = new BoardsizeForm(this);
            boardsizeForm.ShowDialog();

            MinimumSize = new Size(Width, Height);

            MaximumSize = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;

            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = columns;

            tableLayoutPanel1.RowCount = rows;

            tiles = rows * columns;

            for (int i = 0; i < tiles; i++)
            {
                MineButton b = new MineButton();
                b.Width = 32;
                b.Height = 32;
                tableLayoutPanel1.Controls.Add(b);
                b.MouseUp += b_Click;
            }

            PopulateMines();

            for (int i = 0; i < columns; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    CountAdjacent(i, j);
                }

            }
            foreach (ColumnStyle style in tableLayoutPanel1.ColumnStyles)
            {
                style.SizeType = SizeType.AutoSize;
                style.Width = 12.5f;
            }

            foreach (RowStyle style in tableLayoutPanel1.RowStyles)
            {
                style.SizeType = SizeType.AutoSize;
                style.Height = 12.5f;
            }
        }


        void CountAdjacent(int x, int y)
        {
            MineButton b = (MineButton)tableLayoutPanel1.GetControlFromPosition(x, y);

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                    {
                        continue;
                    }


                    if (x + i < 0 || x + i > tableLayoutPanel1.ColumnCount - 1 || y + j < 0 || y + j > tableLayoutPanel1.RowCount - 1)
                    {
                        continue;
                    }
                    MineButton m = (MineButton)tableLayoutPanel1.GetControlFromPosition(x + i, y + j);

                    if (m.isMine)
                    {
                        b.adjacentMines++;
                    }
                }
            }

        }


        void b_Click(object sender, MouseEventArgs e)
        {
            MineButton b = (MineButton)sender;



            if (e.Button == MouseButtons.Left)
            {
                if (b.isMine == true)
                {
                    MessageBox.Show("Du er død bror");
                    this.Close();
                    Application.Exit();

                }
                else
                {
                    b.isRevealed = true;
                    revealedTiles++;
                    if (tiles - revealedTiles == mineCount)
                    {
                        MessageBox.Show("Du har vundet bror");
                        this.Close();
                        Application.Exit();
                    }
                    if (b.adjacentMines == 0)
                    {
                        TableLayoutPanelCellPosition position = tableLayoutPanel1.GetPositionFromControl(b);
                        int x = position.Column;
                        int y = position.Row;
                        for (int i = -1; i <= 1; i++)
                        {
                            for (int j = -1; j <= 1; j++)
                            {
                                if (i == 0 && j == 0)
                                {
                                    continue;
                                }


                                if (x + i < 0 || x + i > tableLayoutPanel1.ColumnCount - 1 || y + j < 0 || y + j > tableLayoutPanel1.RowCount - 1)
                                {
                                    continue;
                                }
                                MineButton m = (MineButton)tableLayoutPanel1.GetControlFromPosition(x + i, y + j);

                                if (m.isRevealed)
                                {
                                    continue;
                                }

                                b_Click(m, e);
                                

                            }
                        }
                    }


                }
            }
            if (e.Button == MouseButtons.Right)
            {
                b.isFlagged = !b.isFlagged;

            }

            b.Invalidate();



        }
        public void PopulateMines()
        {
            Random rng = new Random();
            for (int i = 0; i < mineCount; i++)
            {
                int x = rng.Next(0, columns);
                int y = rng.Next(0, rows);

                MineButton b = (MineButton)tableLayoutPanel1.GetControlFromPosition(x, y);

                if (b.isMine)
                {
                    i--;
                    continue;
                }

                b.isMine = true;
            }
        }
    }


}
